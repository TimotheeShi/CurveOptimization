#pragma once
#include <math.h>
#include <vector>
#include <utility>
#include <string>
#include <fstream>
#include "Preprocess.h"
#include "PointInspection.h"
#include "Cycloid_Cal.h"

using namespace std;

class CycloidGear
{
public:
	CycloidGear(double Z1, double R1, double r1, double e1) : R(R1), R0(R1), Z(Z1), r(r1), r0(r1), e(e1), e0(e1) {
		zeiss = new std::vector<std::pair<double, double>>;
		zeiss_pol = new std::vector<std::pair<double, double>>;
		flank = new std::vector<std::pair<double, double>>;
		addendum = new std::vector<std::pair<double, double>>;
		root = new std::vector<std::pair<double, double>>;
	};

	~CycloidGear() {
		delete zeiss;
		delete zeiss_pol;
		delete flank;
		delete addendum;
		delete root;
		zeiss = nullptr;
		zeiss_pol = nullptr;
		flank = nullptr;
		addendum = nullptr;
		root = nullptr;
	}

	void setFlankRange(const double lower, const double upper) {
		this->lower = lower;
		this->upper = upper;
	}

	void pointInput(const string* path = nullptr) {
		if (path == nullptr) {
			cout << "�յ�ַ��" << endl;
			return;
		}
		Preprocess pp;
		PointInspection pi;
		if (pp.readData(*path, *zeiss)) {
			if (pp.Car2Pol(*zeiss, *zeiss_pol)) {
				//if (pi.AxisToAddendum(*zeiss, *zeiss_pol))
						//pi.PointRotation(*zeiss, *zeiss_pol, -3.1415926 / Z);
				//pi.SwitchInitialPoint(*zeiss, *zeiss_pol, Z);
				cout << "Read Successfully!" << endl;
				//pi.PointRotation(*zeiss, *zeiss_pol, -zeiss_pol)
				//pi.RotX(*zeiss, *zeiss_pol);
				for (auto point : *zeiss_pol) {
					//if (point.second < 0)
						//point.second = -point.second;
					if (point.first > this->upper / 2)
						addendum->push_back(point);
					else if (point.first < this->lower / 2)
						root->push_back(point);
					else
						flank->push_back(point);
				}
			}
		}
		else
			cout << "Fail to Read!" << endl;
	}

	void shuffle(std::vector<std::pair<double, double>>* points) {
		std::vector<std::pair<double, double>>* new_points = new std::vector<std::pair<double, double>>;
		for (int i = 0; i < Z; i++) {
			for (int j = i; j < points->size(); j += Z) {
				new_points->push_back((*points)[j]);
			}
		}
		std::swap(new_points, points);
	}

	void pointOutput() {
	}

	void paramsOutput() {
		cout << "���߳��ֳ���Ϊ��" << Z;
		cout << "\n���۰��߲���Ϊ��\n\tR = " << R0 << "\n\tr = " << r0 << "\n\te = " << e0;
		cout << "\nʵ�ʰ��߲���Ϊ��\n\tR = " << R << "\n\tr = " << r << "\n\te = " << e;
		cout << endl;
	}

	void paramsopt() {
		double obj = 0;
		double old_obj = 0;
		double diff_obj = 1000;
		int j = 0;
		int k = 0;
		while (diff_obj * diff_obj >= 1e-4) {
			vector<double> res2;
			vector<double> jacobian_R;
			vector<double> jacobian_r;
			vector<double> jacobian_e;
			for (int i = 0; i < flank->size(); ++i) {
				double row = cycloid_row((*flank)[i].second, R, Z, r, e);
				double res = (*flank)[i].first - row;
				res2.push_back(res * res);
				std::vector<double> d = cycloid_derivative((*flank)[i].second, R, Z, r, e);
				jacobian_R.push_back(res * -d[0]);
				jacobian_r.push_back(res * -d[1]);
				jacobian_e.push_back(res * -d[2]);
			}
			old_obj = obj;
			obj = 0.5 * vec_sum(res2);
			double dR = vec_sum(jacobian_R);
			double dr = vec_sum(jacobian_r);
			double de = vec_sum(jacobian_e);
			R -= 0.0000001 * dR;
			r -= 0.0000001 * dr;
			e -= 0.0000001 * de;
			diff_obj = old_obj - obj;
			cout << "[" << ++j << "] object function: " << obj << ", diff_obj: " << diff_obj << ", R=" << R << ", r=" << r << ", e=" << e << endl;
		}
	}

	double vec_sum(const vector<double>& vec) {
		double sum = 0.0;
		for (auto itr = vec.cbegin(); itr != vec.cend(); ++itr)
			sum += *itr;
		return sum;
	}

	// variables with the postfix "0" are the theoretical values (which are also initial values of the optimition).
	double R = 0, R0 = 0;
	double Z = 0;
	double r = 0, r0 = 0;
	double e = 0, e0 = 0;
	double upper = R;
	double lower = 0;
	std::vector<std::pair<double, double>>* zeiss;
	std::vector<std::pair<double, double>>* zeiss_pol;
	std::vector<std::pair<double, double>>* flank;
	std::vector<std::pair<double, double>>* addendum;
	std::vector<std::pair<double, double>>* root;

	double signs(double d) {
		double res = 0;
		if (d > 0)
			res = 1;
		if (d < 0)
			res = -1;
		return res;
	}

	double 
};

